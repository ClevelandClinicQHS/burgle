#' @name burgle_
#'
#' @export
burgle.CauseSpecificCox <- function(object, ...){

  models <- object$models
  evtimes <- object$eventTimes
  Net <- length(evtimes)

  basehzs <- lapply(models, function(x) riskRegression::predictCox(x, centered = FALSE,
                                                                   times = evtimes, newdata = NULL, type = c("hazard", "cumhazard"), keep.strata = TRUE, keep.times = TRUE,
                                                                   se = FALSE, keep.infoVar = TRUE))

  cumhazards <- lapply(basehzs, function(x) matrix(x[["cumhazard"]], byrow = FALSE, nrow = Net))
  hazards <- lapply(basehzs, function(x) matrix(x[["hazard"]], byrow = FALSE, nrow = Net))
  levT <- lapply(basehzs, `[[`, "lastEventTime")
  coefs <- lapply(models, stats::coef)

  vcovs <- mapply(function(x, y) if(length(x) == 0L){return(matrix(0))}else{stats::vcov(y)}, coefs, models, SIMPLIFY = FALSE)

  terms <- lapply(models, stats::terms)
  terms <- lapply(terms, stats::delete.response)

  # terms <- delete.response(terms)
  # terms <- lapply(terms, delete.env)
  terms <- lapply(terms, function(x){
    attr(x, ".Environment") <- NULL
    return(x)
  })

  evtimes <- object$eventTimes

  xlevels <- lapply(object$models, `[[`, "xlevels")
  contrasts <- lapply(object$models, `[[`, "contrasts")

  l <- list("cumhazards" = cumhazards,
            "hazards" = hazards,
            "eventTimes"  = evtimes,
            "Lastevent" = levT,
            "coef" = coefs,
            "cov" = vcovs,
            "xlevels" = xlevels,
            "contrasts" = contrasts,
            # "formulas" = formulas,
            "terms" = terms
  )

  class(l) <- "burgle_CauseSpecificCox"
  l

}

# delete.env <- function(x){attr(x, ".Environment") <- NULL; return(x)}

predictCIF_cpp <- get("predictCIF_cpp", envir = asNamespace("riskRegression"), inherits = FALSE)

#' @name predict_burgle
#'
#' @param cause which cause do you want to predict
#'
#' @export
predict.burgle_CauseSpecificCox <- function(object, newdata = NULL, type = "lp", cause = 1, original = TRUE, draws = 1, sims = 1, times = NULL, ...) {
  if(!is.data.frame(newdata)) stop("newdata must be an object of class data.frame")
  nMods <- length(object$cumhazards)
  if(!is.numeric(cause)| cause < 0| cause > nMods) stop("Invalid cause")
  type <- match.arg(tolower(type), c("lp", "response", "risk"))
  nOs <- nrow(newdata)
  ### check strata
  str_cks <- lapply(object$xlevels, function(x) grepl("strata", names(x)))
  o_xlvs <- xlvs <- object$xlevels

  new_xlvs <- vector(mode = "list", length = nMods)
  M.strata <- matrix(NA, nrow = nOs, ncol = nMods)
  M.eTime <- matrix(NA, nrow = nOs, ncol = nMods)

  for(i in 1:nMods){
    str_ck <- str_cks[[i]]
    o1 <- object$xlevels[[i]]
    n1 <- new_xlvs[[i]]

    if(any(str_ck)){
      str1 <- o1[str_ck]
      str_lv <- factor(str1[[1]])
      o_xlvs[[i]] <- o1 <- o1[!str_ck]
      str1n <- names(str1)
      str1_v <- strsplit(gsub("strata|\\)|\\(", "", str1n), ", ")[[1]]
      vn <- length(str1_v)
      str1_ls <- strsplit(str1[[1]], ", ")
      n1 <- lapply(seq_len(vn), function(y) unique(sapply(str1_ls, function(x) x[y])))
      names(n1) <- str1_v
      xlvs[[i]] <- append(o1, n1)
      ## New strata
      attr(M.strata, paste0("levels", i)) <- as.character(str_lv)
      str_s <- as.numeric(factor(survival::strata(newdata[,names(n1)], shortlabel = TRUE), levels = str_lv))-1
      M.strata[,i] <- str_s

    }else{
      M.strata[,i] <- 0
      attr(M.strata, paste0("levels", i)) <- factor(1)
    }

    M.eTime[, i] <- object$Lastevent[[i]][M.strata[, i] + 1]

  }

  vec.Etime <- apply(M.eTime, 1, max)

  if(original & draws > 1){
    stop("Can only have one draw from the original model")
  }
  o_coef <- object$coef
  no_coef <- sapply(o_coef, is.null)
  if(any(no_coef)){
    o_coef[no_coef] <- 0L
  }

  if(original){
    models <- o_coef
  }else{
    models <- lapply(1:nMods, function(x) MASS::mvrnorm(n = draws, mu = o_coef[[x]], Sigma = object$cov[[x]]))
  }
  ## add to something if only one covariate
  # mms <- lapply(1:nMods, function(x) stats::model.matrix(stats::reformulate(object$formula[[x]]), data = newdata, xlev = o_xlvs[[x]], contrasts.arg = object$contrasts.arg[[x]]))
  mms <- lapply(1:nMods, function(x) stats::model.matrix(object$terms[[x]], data = newdata, xlev = o_xlvs[[x]], contrasts.arg = object$contrasts[[x]])[,-1])

  if(nOs == 1){
    mms <- lapply(mms, function(x) matrix(x, ncol = length(x)))
  }

  if(any(no_coef)){
    # mms[!no_coef] <- lapply(mms[!no_coef], function(x) matrix(x, nrow = nrow(newdata)))
    mms[no_coef] <- lapply(mms[no_coef], function(x) matrix(0, nrow = nrow(newdata)))
  }

  ##### weird bug here, with binding rows at each step
  preds <- mapply(function(x, y){
    if(!is.null(dim(x))){
      # p1 <- apply(x, 1, function(x) y %*% x)
      # p1 <- apply(x, 1, function(x) fastmm(y, x))
      p1 <- fastmm(y, t(x))
    }else{
      # p1 <- y %*% x
      p1 <- fastmm(y, matrix(x))
    }
    p1
  }, models, mms, SIMPLIFY = TRUE)
  #
  # return(preds)

  if(nrow(newdata) == 1L & draws == 1L){preds <- matrix(preds, nrow = 1)}

  if(nrow(preds) > nrow(newdata)){
    ov <- (nrow(newdata) * 1:draws)-nrow(newdata)
    if(length(ov) == 1L){ov <- 1}
    preds <- mapply(function(x, y) preds[c(x:y), ], ov, (nrow(newdata) *1:draws), SIMPLIFY = FALSE)
  }
  if(type == "lp"){
    return(preds)
  }

  if(is.null(times)) stop("times is missing")
  if(is.unsorted(times)) warning("times is unsorted")
  if(max(times) > max(sapply(object$Lastevent, max))) warning(paste("times has a value of", max(times), "which is larger than the maximum time value of", max(sapply(object$Lastevent, max)), "risk esimates may be NA or unreliable"))


  if(is.list(preds)){
    preds <- lapply(preds, function(x) predictCIF_cpp(hazard = object$hazard, cumhazard = object$cumhazards,
                                                      eXb = exp(x), strata = M.strata, newtimes = times, etimes = object$eventTimes, etimeMax = vec.Etime,
                                                      t0 = 0, nEventTimes = length(object$eventTimes), nNewTimes = length(times),
                                                      nData = nrow(newdata), cause = cause - 1, nCause = nMods,
                                                      survtype = FALSE, productLimit = TRUE >
                                                        0, diag = FALSE, exportSurv = FALSE)[["cif"]])
  }else{
    preds <- predictCIF_cpp(hazard = object$hazard, cumhazard = object$cumhazards,
                            eXb = exp(preds), strata = M.strata, newtimes = times, etimes = object$eventTimes, etimeMax = vec.Etime,
                            t0 = 0, nEventTimes = length(object$eventTimes), nNewTimes = length(times),
                            nData = nrow(newdata), cause = cause - 1, nCause = nMods,
                            survtype = FALSE, productLimit = TRUE >
                              0, diag = FALSE, exportSurv = FALSE)[["cif"]]
  }

  if(type == "risk"){
    return(preds)
  }

  if(sims >= 1L & type == "response"){
    if(!is.null(dim(preds))){
      # preds <- replicate(sims, apply(preds, MARGIN = 2, function(x) stats::rbinom(n = length(x), size = 1, prob = x)), simplify = FALSE)
      preds <- simulate_responses_binom(preds, sims)
      if(sims == 1L) preds <- preds[[1]]
    }else{
      # preds <- lapply(preds, function(y) replicate(sims, apply(y, MARGIN = 2, function(x) stats::rbinom(n = length(x), size = 1, prob = x)), simplify = FALSE))
      preds <- lapply(preds, function(y) simulate_responses_binom(y, sims))
      if(sims < 2) preds <- lapply(preds, function(x) if(length(x) == 1) x[[1]] else x)
      }
  }
  preds

}
